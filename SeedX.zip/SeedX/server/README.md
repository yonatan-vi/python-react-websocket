# python websocker server

## Run locally
1. pip install
2. python ./app/mywebsocket.py

## How to run

1. docker build -t dockerpython .
2. docker run -p 8765:8765 dockerpython
