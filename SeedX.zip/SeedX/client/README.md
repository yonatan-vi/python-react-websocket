## Genee
Websocket client for seeds analysis.


## Run locally
1. yarn install
2. yarn start

## Docker Setup
1. docker build . -t reactwebsocketimage
2. docker run reactwebsocketimage

browse to http://localhost:3000/
